#!/usr/bin/with-contenv bashio

DEF_VOL=$(bashio::config 'volume')

bashio::log.info "Starting new session..."
bashio::log.info "Default volume = ${DEF_VOL}"
# amixer sset Master ${DEF_VOL}%

python3 pa.py
# if ! msg="$(python3 /pa.py)"; then
	# bashio::log.error "Web server start failed -> ${msg}"
# else
	# bashio::log.error "Web server start succeeded -> ${msg}"
# fi

# Read from STDIN aliases to play file
# Will it ever get here? Perhaps not

while read -r input; do

	echo "======================================================="

  # removing JSON stuff
  input="$(echo "$input" | jq --raw-output '.')"
	bashio::log.info "Read alias: ${input}"

done
