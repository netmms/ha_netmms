from http.server import BaseHTTPRequestHandler, HTTPServer
import ssl, cgi
import os, sys, time
import _thread

def get_ip_address():
	# do not make any assumptions about the order of the output!
	ip_list = os.popen("hostname -i").read().split()
	for ip in (ip_list):
		if ":" in ip: continue
		else: return ip.strip()

def read_file(fname):
	if not os.path.isfile(fname):
		return ''
	file = open(fname, 'rb')
	content = file.read()
	file.close()
	return content
	
def content_type(path):	
	ext = os.path.splitext(path)[1][1:]
	if   ext == 'css':	type = 'text/css'
	elif ext == 'ico':	type = 'image/x-icon'
	elif ext == 'png':	type = 'image/png'
	elif ext == 'jpg':	type = 'image/jpeg'
	elif ext == 'gif':	type = 'image/gif'
	elif ext == 'wav':	type = 'audio/wav'
	elif ext == 'js':	type = 'application/javascript'
	elif ext == 'zip':	type = 'application/x-zip'
	elif ext == 'gz':	type = 'application/x-gzip'
	else:				type = 'text/html'
	return type

host_name = get_ip_address()
host_port = 8000
play_prog = 'aplay'

class MyServer(BaseHTTPRequestHandler):
	def do_HEAD(self, type):
		self.send_response(200)
		self.send_header('Content-type', type)
		self.end_headers()

	def _redirect(self, path):
		self.send_response(303)
		self.send_header('Content-type', 'text/html')
		self.send_header('Location', path)
		self.end_headers()

	def do_GET(self):
		path = self.path
		if path == '/': path = '/index.html'

		path = 'html' + path

		html = read_file(path)
		if html == '':
			self.send_error(404)
		else:
			self.do_HEAD(content_type(path))
			self.wfile.write(html)

	def do_POST(self):
		form = cgi.FieldStorage(fp=self.rfile, headers=self.headers,
			environ={'REQUEST_METHOD':'POST',
				'CONTENT_TYPE':self.headers['Content-Type'],
				})

		file = open('msg.wav', 'wb')
		file.write(form.getfirst('audio_data'))
		file.close()

		os.system("./play_msg.sh")
			
		self._redirect('/')	# Redirect back to the root url

def init_server(flag, port):

	print(flag,port)
	httpd = HTTPServer((host_name, port), MyServer)

	if flag == 2:
		httpd.socket = ssl.wrap_socket(httpd.socket, 
			keyfile='pzpray.local.key.pem', 
			certfile='pzpray.local.cert.pem', server_side=True)
 
	print("Server Started - %s:%s" %(host_name, port))

	httpd.serve_forever()
	httpd.server_close()

VERBOSE = "True"

if __name__ == '__main__':

	_thread.start_new_thread(init_server, (1,8001,))
	_thread.start_new_thread(init_server, (2,8000,))

	# try:
		# while 1:
			# time.sleep(5000)
	# except KeyboardInterrupt:
		# print("Received keyboard interrupt")
		# sys.exit()
