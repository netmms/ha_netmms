//webkitURL is deprecated but nevertheless
URL = window.URL || window.webkitURL;

var gumStream; 						//stream from getUserMedia()
var rec; 							//Recorder.js object
var input; 							//MediaStreamAudioSourceNode we'll be recording
var isRecording = false;

// shim for AudioContext when it's not avb. 
var AudioContext = window.AudioContext || window.webkitAudioContext;
var audioContext //audio context to help us record

var recordButton = document.getElementById("recordButton");

var recDelay;

//if (navigator.userAgent.indexOf("Firefox") != -1) {
//	recDelay = 5000;
//}
//else {
//	recDelay = 1000;
//}

//add events to those 2 buttons
recordButton.addEventListener("click", toggleRecording);

function setRecElements(doRecording) {
	if (doRecording) {
		isRecording = true;
		recordButton.innerHTML = "Finish";
		recordButton.style.backgroundColor = "#ed341d";
		document.getElementById("status").innerHTML="Recording...";
	}
	else {
		isRecording = false;
		recordButton.innerHTML = "Record";
		recordButton.style.backgroundColor = "#6b8e23";
		document.getElementById("status").innerHTML="Waiting...";
	}
}

function delayedStartRec() {
		startRecording();
}

var timeWent;
var myTimer;

function incTimer() {
	if(timeWent >= 10) {
		clearInterval(myTimer);
	}
	document.getElementById("counter").innerHTML = timeWent;
	timeWent += 1;
}
	
function toggleRecording() {
	if (isRecording) {
		stopRecording();
	}
	else {
		var timeWent = 1;
		var myTimer = setInterval(function(){
		  if(timeWent >= 10){
		    clearInterval(myTimer);
//    		timeWent = "";
		  }
		  document.getElementById("counter").innerHTML = timeWent;
		  timeWent += 1;
		}, 1000);		

		// this block was added since FireFox chops off the neginning of the recording for some reason
//		recordButton.innerHTML = "Wait";
//		recordButton.style.backgroundColor = "#ff8c00";
//		document.getElementById("status").innerHTML="Preparing...";		
//		setTimeout(delayedStartRec, recDelay); //delay is in milliseconds 
		startRecording();
	}
}

function startRecording() {
	console.log("recordButton clicked");

	/*
		Simple constraints object, for more advanced audio features see
		https://addpipe.com/blog/audio-constraints-getusermedia/
	*/
	
	var constraints = { audio: true, video:false }

 	/*
		Disable the record button until we get a success or fail from getUserMedia() 
	*/

	/*
		We're using the standard promise based getUserMedia() 
		https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia
	*/

	navigator.mediaDevices.getUserMedia(constraints).then(function(stream) {
		console.log("getUserMedia() success, stream created, initializing Recorder.js ...");

		/*
			create an audio context after getUserMedia is called
			sampleRate might change after getUserMedia is called, like it does on macOS when recording through AirPods
			the sampleRate defaults to the one set in your OS for your playback device

		*/
		audioContext = new AudioContext();

		//update the format 
		document.getElementById("formats").innerHTML="Format: 1 channel pcm @ "+audioContext.sampleRate/1000+"kHz";
		setRecElements(true);

		/*  assign to gumStream for later use  */
		gumStream = stream;
		
		/* use the stream */
		input = audioContext.createMediaStreamSource(stream);

		/* 
			Create the Recorder object and configure to record mono sound (1 channel)
			Recording 2 channels  will double the file size
		*/
		rec = new Recorder(input,{numChannels:1})

		//start the recording process
		rec.record()

		console.log("Recording started");

	}).catch(function(err) {
	  	//enable the record button if getUserMedia() fails
		setRecElements(false);
	});
}

function stopRecording() {
	console.log("stopButton clicked");

	//disable the stop button, enable the record too allow for new recordings
	setRecElements(false);
	
	//tell the recorder to stop the recording
	rec.stop();

	//stop microphone access
	gumStream.getAudioTracks()[0].stop();

	//create the wav blob and pass it on to createDownloadLink
	rec.exportWAV(createDownloadLink);
}

function createDownloadLink(blob) {
	
	var url = URL.createObjectURL(blob);

	//name of .wav file to use during upload and download (without extendion)
	var filename = new Date().toISOString();
	var xhr=new XMLHttpRequest();
	xhr.onload=function(e) {
		if(this.readyState === 4) {
			console.log("Server returned: ",e.target.responseText);
		}
	};

	var fd=new FormData();
	fd.append("audio_data", blob, filename);
	xhr.open("POST", "/", true);
	xhr.send(fd);
}
